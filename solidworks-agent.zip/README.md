# Hacint SolidWorks Agent

This Windows agent allows the Hacint ERP website to download a CAD file and
open it directly in the locally installed SolidWorks application.

## Supported files

- `.SLDPRT`
- `.SLDASM`
- `.SLDDRW`
- `.STEP` / `.STP`
- `.IGES` / `.IGS`
- `.DXF`

## Requirements

- Windows 10 or Windows 11
- SolidWorks installed and activated
- Node.js LTS installed from <https://nodejs.org/>

The agent must be installed on every Programmer or CNC computer that needs to
open files in SolidWorks. The ERP server can run on a different computer.

## Recommended installation

1. Extract every file from `solidworks-agent.zip` into a permanent local folder.
2. Do not run the scripts from inside the ZIP preview.
3. Double-click `install-solidworks-bridge.bat`.
4. Keep the bridge window open during the first test.
5. The installer adds the agent to Windows Startup for future sessions.

Windows may display a security warning for a downloaded script. Confirm that
the files came from your ERP administrator before choosing **Run anyway**.

## Verify the agent

On the same computer, open this address in a browser:

```text
http://127.0.0.1:43127/health
```

A working installation returns JSON similar to:

```json
{
  "ok": true,
  "solidWorksInstalled": true,
  "executable": "C:\\Program Files\\SOLIDWORKS Corp\\SOLIDWORKS\\SLDWORKS.exe"
}
```

Then open the ERP and click **View in SolidWorks** from the Programmer or CNC
page. The regular download button remains available as a fallback.

## Manual start

If the agent is installed but not running, double-click:

```text
start-solidworks-bridge.bat
```

Keep the command window open. A successful startup displays:

```text
[OK] Hacint SolidWorks Bridge listening on http://127.0.0.1:43127
[OK] SolidWorks found: C:\...\SLDWORKS.exe
```

## Custom SolidWorks installation path

If `/health` returns `"solidWorksInstalled": false`, locate `SLDWORKS.exe` on
the computer. Open PowerShell and run:

```powershell
setx SOLIDWORKS_EXE_PATH "C:\actual\path\to\SLDWORKS.exe"
```

Close the existing bridge window and start it again. Reopen `/health` and
confirm that `"solidWorksInstalled"` is now `true`.

## Troubleshooting

### The health page cannot be reached

The agent is not running. Start `start-solidworks-bridge.bat`. If it reports
that Node.js is missing, install Node.js LTS and try again.

### Node.js says `MODULE_NOT_FOUND`

The files were not extracted together, or the command was started from the
wrong folder. Extract the complete ZIP and use the included `.bat` files. The
following files must remain in the same folder:

```text
README.md
solidworks-bridge.mjs
start-solidworks-bridge.bat
install-solidworks-bridge.bat
```

### The ERP says the local agent cannot be found

First verify that `/health` opens on the same computer and returns `"ok": true`.
Then refresh the ERP with `Ctrl+F5` and try again.

### SolidWorks is found but asks for activation or login

Open SolidWorks manually and complete its normal license activation or account
login. Once SolidWorks opens successfully by itself, close it and retry from
the ERP.

### Port 43127 is already in use

Close duplicate bridge windows. Ensure another application is not using port
`43127`, then start the agent again.

## Security and operation

- The agent listens only on `127.0.0.1`; it is not exposed to other computers.
- Received files are stored temporarily in the Windows temporary directory.
- Do not move or delete the extracted agent folder after installing Startup.
- Install and run the agent only on trusted Programmer and CNC computers.
